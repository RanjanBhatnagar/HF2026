﻿namespace NewExceptionDemo.Models
{
        public class ErrorDetails
        {
            public int StatusCode { get; set; }
            public string Message { get; set; } = string.Empty;
            public string? Detailed { get; set; }
            public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        }
}

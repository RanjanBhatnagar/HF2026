﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewExceptionDemo.Models;

namespace NewExceptionDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private static readonly List<Product> Products = new()
        {
            new Product { Id = 1, Name = "Laptop", Price = 999.99m, StockQuantity = 10 },
            new Product { Id = 2, Name = "Mouse", Price = 25.50m, StockQuantity = 50 },
            new Product { Id = 3, Name = "Keyboard", Price = 75.00m, StockQuantity = 30 }
        };

        [HttpGet("{id:int}")]
        public ActionResult<ProductResponseDto> GetProductById(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException("Product ID must be greater than zero.");
            }

            var product = Products.FirstOrDefault(p => p.Id == id);
            if (product == null)
            {
                throw new KeyNotFoundException($"Product with ID {id} was not found.");
            }

            var responseDto = new ProductResponseDto
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price
            };

            return Ok(responseDto);
        }
    }
}

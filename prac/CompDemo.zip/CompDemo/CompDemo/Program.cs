﻿namespace CompDemo
{
    public class Program
    {
        static void Main(string[] args)
        {        

            //List<Employee> empList = new List<Employee>();
            //Employee e1 = new Employee(101, "Ram", 45588M);
            //Employee e2 = new Employee(102, "Shyam", 235588M);
            //Employee e3 = new Employee(103, "Hari", 56488M);
            //Employee e4 = new Employee(104, "Akash", 12345M);
            //Employee e5 = new Employee(105, "Sita", 46568M);

            //empList.Add(e1);
            //empList.Add(e2);
            //empList.Add(e3);
            //empList.Add(e4);
            //empList.Add(e5);

            List<Employee> empList = new List<Employee>()
            {
                new Employee(101, "Ram", 45588M),
                new Employee(102, "Shyam", 235588M),
                new Employee(103, "Hari", 56488M),
                new Employee(104, "Akash", 12345M),
                new Employee(105, "Sita", 46568M)
            };

            //Emp Records
            Console.WriteLine("\nEmp Records\n");
            foreach (Employee e in empList)
            {
                Console.WriteLine(e);
            }

            //Emp Records arranged in ascending order of Name
            Console.WriteLine("\nEmp Records arranged in ascending order of Name\n");
            empList.Sort();
            Console.WriteLine("\nEmp Records\n");
            foreach (Employee e in empList)
            {
                Console.WriteLine(e);
            }

            //Emp Records arranged in descending order of Name
            Console.WriteLine("\nEmp Records arranged in ascending order of Name\n");
            empList.Sort(new EmpSalaryCompDescName());
            Console.WriteLine("\nEmp Records\n");
            foreach (Employee e in empList)
            {
                Console.WriteLine(e);
            }

            //Emp Records arranged in ascending order of Salary
            Console.WriteLine("\nEmp Records arranged in ascending order of Salary\n");
            //empList.Sort();       //using default CompareTo method of Employee class

            empList.Sort(new EmpSalaryComp());

            Console.WriteLine("\nEmp Records ascending order of Salary\n");
            foreach (Employee e in empList)
            {
                Console.WriteLine(e);
            }


            //Emp Records arranged in descending order of Salary
            Console.WriteLine("\nEmp Records arranged in descending order of Salary\n");
            //empList.Sort();       //using default CompareTo method of Employee class

            empList.Sort(new EmpSalaryCompDesc());

            Console.WriteLine("\nEmp Records descending order of Salary\n");
            foreach (Employee e in empList)
            {
                Console.WriteLine(e);
            }
        }
    }
}

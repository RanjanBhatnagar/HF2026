﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompDemo
{
    //Descending order of name
    public class EmpSalaryCompDescName : IComparer<Employee>
    {
        public int Compare(Employee? x, Employee? y)
        {
            return y.Name.CompareTo(x.Name);
        }
    }
    //Ascending order of salary
    public class EmpSalaryComp : IComparer<Employee>
    {
        public int Compare(Employee? x, Employee? y)
        {
            return x.Salary.CompareTo(y.Salary);
        }
    }

    //Descending order of salary
    public class EmpSalaryCompDesc : IComparer<Employee>
    {
        public int Compare(Employee? x, Employee? y)
        {
            return y.Salary.CompareTo(x.Salary);
        }
    }
}

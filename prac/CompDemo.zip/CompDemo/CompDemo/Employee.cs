﻿namespace CompDemo
{
    //public class Employee : IComparable // for default sorting order
    public class Employee : IComparable<Employee>
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public decimal Salary { get; set; }
        public Employee()
        {

        }
        public Employee(int id, string name, decimal salary)
        {
            Id = id;
            Name = name;
            Salary = salary;
        }

        public override string ToString()
        {
            return "Id:" + Id + "  Name:" + Name + "  Salary:" + Salary;
        }

        //public int CompareTo(Employee? other)
        //{
        //    return other.Salary.CompareTo(this.Salary);

        //}


        public int CompareTo(Employee? other)
        {
            return this.Name.CompareTo(other.Name);
        }


        //public int CompareTo(object? obj)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EmployeeOnboarding } from "../tempform/employee-onboarding/employee-onboarding";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, EmployeeOnboarding],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('employee-onboarding');
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpOnboardingReactive } from './emp-onboarding-reactive';

describe('EmpOnboardingReactive', () => {
  let component: EmpOnboardingReactive;
  let fixture: ComponentFixture<EmpOnboardingReactive>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmpOnboardingReactive]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpOnboardingReactive);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

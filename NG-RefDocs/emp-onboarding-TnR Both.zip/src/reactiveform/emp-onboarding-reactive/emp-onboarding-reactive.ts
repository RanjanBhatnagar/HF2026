import { Component } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ReactiveFormsModule, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';

@Component({
  selector: 'app-emp-onboarding-reactive',
  imports: [ReactiveFormsModule],
  templateUrl: './emp-onboarding-reactive.html',
  styleUrl: './emp-onboarding-reactive.css',
})



export class EmpOnboardingReactive {
  submitted = false;

  departments = [
    'IT',
    'HR',
    'Finance',
    'Marketing',
    'Operations'
  ];

  employmentTypes = [
    'Full Time',
    'Part Time',
    'Contract',
    'Internship'
  ];

  skills = [
    'Angular',
    'TypeScript',
    'React',
    '.NET',
    'SQL',
    'Azure'
  ];
  employeeForm = new FormGroup({

    employeeName: new FormControl('', [
      Validators.required,
      Validators.minLength(3)
    ]),

    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),

    password: new FormControl('', [
      Validators.required,
      Validators.minLength(8)
    ]),

    age: new FormControl<number | null>(null, [
      Validators.required,
      Validators.min(18),
      Validators.max(60)
    ]),

    joiningDate: new FormControl('', [
      Validators.required
    ]),

    gender: new FormControl('', [
      Validators.required
    ]),

    department: new FormControl('', [
      Validators.required
    ]),

    employmentType: new FormControl('', [
      Validators.required
    ]),

    skills: new FormControl<string[]>([], [
      atLeastOneSkill()
    ]),

    address: new FormControl('', [
      Validators.required,
      Validators.minLength(10)
    ]),

    termsAccepted: new FormControl(false, [
      Validators.requiredTrue
    ])

  });

  get f() {
    return this.employeeForm.controls;
  }

  toggleSkill(
    skill: string,
    checked: boolean
  ): void {

    const currentSkills =
      this.f.skills.value ?? [];

    let updatedSkills: string[];

    if (checked) {

      updatedSkills = currentSkills.includes(skill)
        ? currentSkills
        : [...currentSkills, skill];

    } else {

      updatedSkills =
        currentSkills.filter(s => s !== skill
        );

    }

    this.f.skills.setValue(updatedSkills);
    this.f.skills.markAsTouched();
    this.f.skills.updateValueAndValidity();
  }

  submitForm(): void {

    if (this.employeeForm.invalid) {

      this.employeeForm.markAllAsTouched();

      return;
    }

    console.log(
      'Employee Data:',
      this.employeeForm.value
    );

    this.submitted = true;
  }

  resetForm(): void {

    this.employeeForm.reset({
      employeeName: '',
      email: '',
      password: '',
      age: null,
      joiningDate: '',
      gender: '',
      department: '',
      employmentType: '',
      skills: [],
      address: '',
      termsAccepted: false
    });

    this.submitted = false;
  }
}

function atLeastOneSkill(): ValidatorFn {

  return (
    control: AbstractControl
  ): ValidationErrors | null => {

    const skills = control.value;

    return Array.isArray(skills) &&
      skills.length > 0
      ? null
      : { required: true };
  };
}
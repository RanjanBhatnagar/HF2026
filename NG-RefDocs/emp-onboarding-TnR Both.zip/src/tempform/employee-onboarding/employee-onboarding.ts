import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'app-employee-onboarding',
  imports: [FormsModule],
  templateUrl: './employee-onboarding.html',
  styleUrl: './employee-onboarding.css',
})
export class EmployeeOnboarding {
  employee = {
    employeeName: '',
    email: '',
    password: '',
    age: null,
    joiningDate: '',
    gender: '',
    department: '',
    employmentType: '',
    skills: [] as string[],
    address: '',
    termsAccepted: false
  };
  departments: string[] = [
    'IT',
    'HR',
    'Finance',
    'Marketing',
    'Operations'
  ];

  employmentTypes: string[] = [
    'Full Time',
    'Part Time',
    'Contract',
    'Internship'
  ];

  skills: string[] = [
    'Angular',
    'TypeScript',
    'React',
    '.NET',
    'SQL',
    'Azure'
  ];

  toggleSkill(skill: string, checked: boolean): void {

    if (checked) {

      if (!this.employee.skills.includes(skill)) {
        this.employee.skills.push(skill);
      }

    } else {

      this.employee.skills =
        this.employee.skills.filter(s => s !== skill);

    }
  }
  submitted = false;
  submitForm(form: NgForm): void {

    if (form.invalid) {
      form.control.markAllAsTouched();
      return;
    }

    console.log('Employee Data:', this.employee);

    this.submitted = true;
  }

  resetForm(form: NgForm): void {

    form.resetForm();

    this.employee = {
      employeeName: '',
      email: '',
      password: '',
      age: null,
      joiningDate: '',
      gender: '',
      department: '',
      employmentType: '',
      skills: [],
      address: '',
      termsAccepted: false
    };

    this.submitted = false;
  }

}

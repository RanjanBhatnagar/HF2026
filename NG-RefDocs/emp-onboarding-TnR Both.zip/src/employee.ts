export interface Employee {
    employeeName: string;
    email: string;
    password: string;
    age: number | null;
    joiningDate: string;
    gender: string;
    department: string;
    employmentType: string;
    skills: string[];
    address: string;
    termsAccepted: boolean;
}


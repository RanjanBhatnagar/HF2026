import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EmployeeOnboarding } from "../tempform/employee-onboarding/employee-onboarding";
import { EmpOnboardingReactive } from '../reactiveform/emp-onboarding-reactive/emp-onboarding-reactive';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, EmployeeOnboarding, EmpOnboardingReactive],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('employee-onboarding');
}
